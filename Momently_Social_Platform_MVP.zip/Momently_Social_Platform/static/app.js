document.addEventListener("DOMContentLoaded", () => {
  const message = document.getElementById("message");
  const counter = document.getElementById("char-count");
  if (message && counter) {
    const update = () => counter.textContent = String(message.value.length);
    message.addEventListener("input", update); update();
  }
  document.querySelectorAll("[data-copy]").forEach(button => {
    button.addEventListener("click", async () => {
      const value = button.getAttribute("data-copy");
      try {
        await navigator.clipboard.writeText(new URL(value, window.location.href).href);
        const old = button.textContent;
        button.textContent = "Copied ✓";
        setTimeout(() => button.textContent = old, 1800);
      } catch (_) {
        window.prompt("Copy this link:", new URL(value, window.location.href).href);
      }
    });
  });
});
